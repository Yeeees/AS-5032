﻿$(document).ready(function () {
    $("p1").click(function () {
        $(this).hide();
    });
});