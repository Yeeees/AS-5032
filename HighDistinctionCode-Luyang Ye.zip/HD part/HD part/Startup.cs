﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(HD_part.Startup))]
namespace HD_part
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
